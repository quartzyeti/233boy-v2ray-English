#!/bin/bash

args=$@
is_sh_ver=v4.21

. /etc/v2ray/sh/src/init.sh
